from .evtx import *

__doc__ = evtx.__doc__
if hasattr(evtx, "__all__"):
    __all__ = evtx.__all__